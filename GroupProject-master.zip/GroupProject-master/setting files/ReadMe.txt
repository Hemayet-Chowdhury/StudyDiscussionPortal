These are some files that were changed during the process of creating the project.
